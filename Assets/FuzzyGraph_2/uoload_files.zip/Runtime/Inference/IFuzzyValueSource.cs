namespace FuzzyGraph2.Runtime
{
    public interface IFuzzyValueSource
    {
        bool TryGetFloat(string variableId, out float value);
    }
}