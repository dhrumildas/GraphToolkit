using UnityEngine;

namespace FuzzyGraph2.Editor
{
    public class FG2Importer : MonoBehaviour
    {
        // Start is called once before the first execution of Update after the MonoBehaviour is created
        void Start()
        {
        
        }

        // Update is called once per frame
        void Update()
        {
        
        }
    }
}
