using FuzzyGraph.Runtime;
using UnityEngine;

public class PitQTE : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private GameObject qteCanvas;
    [SerializeField] private TPP_Controller playerController;
    [SerializeField] private Pursuit guardPursuit;
    [SerializeField] private GameObject guard;

    private bool triggered;

    private void OnTriggerEnter(Collider other)
    {
        if (triggered) return;

        Pursuit enteringGuard = other.GetComponentInParent<Pursuit>();
        if (enteringGuard == null || enteringGuard != guardPursuit) return;

        if (!GuardIsChasing()) return;

        BeginPitQTE();
    }

    private bool GuardIsChasing()
    {
        if (FG2GameServices.Instance == null || FG2GameServices.Instance.Context == null) return false;

        if (!FG2GameServices.Instance.Context.TryGet("Guard.PursuePlayer", out FuzzyValue value)) return false;

        return value.type == FuzzyValueType.Bool && value.boolVal;
    }

    private void BeginPitQTE()
    {
        triggered = true;

        if (guardPursuit != null) guardPursuit.enabled = false;
        if (guard != null) guard.SetActive(false);
        if (playerController != null) playerController.enabled = false;
        if (qteCanvas != null) qteCanvas.SetActive(true);

        Debug.Log("[PitQTE] Guard fell into pit. QTE started.");
    }
}