using UnityEngine;

public class VaultGuardSequence : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Transform guard;
    [SerializeField] private Transform player;
    [SerializeField] private ConversationFacing guardFacing;
    [SerializeField] private ConversationFacing playerFacing;
    [SerializeField] private Transform confrontationPoint;

    [Header("Final Confrontation Event")]
    [SerializeField] private string finalConfrontationEvent;

    [Header("Arrival")]
    [SerializeField] private float arrivalDuration = 2.3f;
    [SerializeField] private float stopDistance = 2f;

    private Vector3 startPosition;
    private Vector3 targetPosition;
    private float timer;
    private bool arriving;

    [Header("Chase Scene State")]
    [SerializeField] private GameObject disableDuringChaseA;
    [SerializeField] private GameObject disableDuringChaseB;
    [SerializeField] private GameObject enableDuringChase;

    [Header("Leave Sequence")]
    [SerializeField] private Transform guardDoorPoint;
    [SerializeField] private Transform guardExitPoint;
    [SerializeField] private GameObject exitDoor;
    [SerializeField] private float leaveMoveSpeed = 3.5f;
    [SerializeField] private float leaveRotationSpeed = 8f;
    [SerializeField] private string leaveDialogueID = "GuardVaultLeave";
    [SerializeField] private string guardFinalDialogue = "GuardVaultChase";

    private enum LeaveState
    {
        None,
        WaitDialogue,
        MoveToDoor,
        MoveOut
    }

    private LeaveState leaveState = LeaveState.None;

    private void SetChaseSceneState(bool chaseActive)
    {
        if (disableDuringChaseA != null)
            disableDuringChaseA.SetActive(!chaseActive);

        if (disableDuringChaseB != null)
            disableDuringChaseB.SetActive(!chaseActive);

        if (enableDuringChase != null)
            enableDuringChase.SetActive(chaseActive);
    }

    public void RestoreAfterQTE()
    {
        SetChaseSceneState(false);
    }

    public void BeginArrival()
    {
        if (arriving || guard == null || player == null) return;

        // wake guard up
        guard.gameObject.SetActive(true);

        // set target spot
        startPosition = guard.position;
        targetPosition = confrontationPoint.position;

        timer = 0f;
        arriving = true;

        // look at player while moving
        if (guardFacing != null) guardFacing.BeginFacing(player);

        Debug.Log("[VaultGuard] Arrival started.");
    }

    private void Update()
    {
        if (arriving)
        {
            timer += Time.deltaTime;
            float t = Mathf.Clamp01(timer / arrivalDuration);

            // slide guard to spot
            guard.position = Vector3.Lerp(startPosition, targetPosition, t);

            // done moving
            if (t >= 1f) FinishArrival();
        }

        if (leaveState == LeaveState.WaitDialogue)
        {
            if (!DialogueRunner.IsDialogueOpen) leaveState = LeaveState.MoveToDoor;
            return;
        }

        if (leaveState == LeaveState.MoveToDoor)
        {
            MoveGuardTowards(guardDoorPoint.position);

            if (Vector3.Distance(guard.position, guardDoorPoint.position) <= 0.05f)
            {
                if (exitDoor != null) exitDoor.SetActive(false);
                leaveState = LeaveState.MoveOut;
            }
            return;
        }

        if (leaveState == LeaveState.MoveOut)
        {
            MoveGuardTowards(guardExitPoint.position);

            if (Vector3.Distance(guard.position, guardExitPoint.position) <= 0.05f)
            {
                guard.gameObject.SetActive(false);
                leaveState = LeaveState.None;
                Debug.Log("[VaultGuard] Guard unlocked the door and left.");
            }
        }
    }

    private void FinishArrival()
    {
        arriving = false;
        guard.position = targetPosition;

        if (guardFacing != null) guardFacing.BeginFacing(player);
        if (playerFacing != null) playerFacing.BeginFacing(guard);

        Debug.Log("[VaultGuard] Guard reached player.");

        if (FG2GameServices.Instance != null)
            FG2GameServices.Instance.RaiseEvent(finalConfrontationEvent, guard);
    }

    public void StopFacing()
    {
        // release facing locks
        if (guardFacing != null) guardFacing.StopFacing();
        if (playerFacing != null) playerFacing.StopFacing();
    }

    public void BeginGuardLeave()
    {
        StopFacing();

        if (DialogueGraphLibrary.Instance != null)
            DialogueGraphLibrary.Instance.StartDialogue(leaveDialogueID, guard);

        leaveState = LeaveState.WaitDialogue;
    }

    private void MoveGuardTowards(Vector3 destination)
    {
        destination.y = guard.position.y;
        Vector3 direction = destination - guard.position;

        if (direction.sqrMagnitude > 0.001f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(direction.normalized);
            guard.rotation = Quaternion.Slerp(guard.rotation, targetRotation, leaveRotationSpeed * Time.deltaTime);
        }

        guard.position = Vector3.MoveTowards(guard.position, destination, leaveMoveSpeed * Time.deltaTime);
    }

    public void BeginGuardChase()
    {
        StopFacing();

        SetChaseSceneState(true);

        if (DialogueGraphLibrary.Instance != null)
            DialogueGraphLibrary.Instance.StartDialogue(guardFinalDialogue, guard);
    }
}